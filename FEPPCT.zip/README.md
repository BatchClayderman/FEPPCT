# FEPPCT

This is an implementation of the FEPPCT encryption scheme. 

As old APIs are used in this version, this repo will no longer be under maintenance. 

Please refer to [https://github.com/BatchClayderman/CA-NI-PSI](https://github.com/BatchClayderman/CA-NI-PSI). 
